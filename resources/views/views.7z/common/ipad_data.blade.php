<div class="clearfix"></div>
<div class="col-lg-12 col-md-12 show_review" style="margin-bottom:0; padding-right:0; display:none;">
    <div class="col-lg-4 col-md-4">
        <div class="col-sm-12 review_arts" style="padding:2px;">
            @include("include.right_reviews")
        </div>
    </div>
</div>