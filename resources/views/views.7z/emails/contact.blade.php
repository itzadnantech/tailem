@component('mail::message')
# Contact Form

{{ $msg }}


Thanks,<br>
{{ config('app.name') }}
@endcomponent
