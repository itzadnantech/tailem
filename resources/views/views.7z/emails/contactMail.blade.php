<h2>Hey !</h2> <br><br>

You received an email from : {{ $name }} <br><br>

User details: <br><br>

Name:  {{ $name }}<br>
Email:  {{ $email }}<br> 
Subject:  {{ $subject }}<br>
Message:  {!! $subject !!}<br><br>

Thanks