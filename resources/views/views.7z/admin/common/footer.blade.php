<div align="center">
	<table style="border-collapse: collapse;" border="0" cellpadding="0" width="95%" height="35">
		<tbody>
			<tr>
				<td class="PageFooter" align="right">
					<a target="_blank" href="http://www.evsoft.pk/">Powered By eVISION Softwares </a>
				</td>
			</tr>
		</tbody>
	</table>
</div>
<script type="text/javascript"> 
	$('#artist').tokenize({
		datas: "loadartists",
		searchMaxLength: 30,
		searchMinLength: 3
	});
</script>