<?php
ob_start();
	//error_reporting(1);
	session_start();
	
	?>
	<h1>Welcome here</h1>