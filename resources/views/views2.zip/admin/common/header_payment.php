<title>Control Panel</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="pragma" content="no-cache">
<style type="text/css">
	@import url("styles/styles.css");
	@import url("styles/slidingdoors.css");
	@import url("styles/comp_img_styles.css");
</style>
<script type="text/javascript" src="<?php echo SERVER_ADMIN_PATH;?>js/jsconfig.js"></script>
<script type="text/javascript" src="<?php echo SERVER_ROOTPATH;?>js/jsconfig.js"></script>
<script type="text/javascript" src="<?php echo SERVER_ROOTPATH;?>scripts/jquery.js"></script>
<script type="text/javascript" src="https://js.stripe.com/v1/"></script>
<script type="text/javascript">
	//Stripe.setPublishableKey('pk_test_QL1moeTOkBVq7PmrzzYYpjgC');	// Test key!
	Stripe.setPublishableKey('pk_live_JbooTgTvqHeFvGscQ1BmhBTQ');	// Live key!
</script>
<script type="text/javascript" src="<?php echo SERVER_ROOTPATH;?>scripts/payment-controller.js"></script>
<script type="text/javascript" src="js/dropdowntabs.js" language="javascript"></script>