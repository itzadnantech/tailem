<?php
// ob_start();
// //error_reporting(1);
// session_start();
// foreach ($_POST  as $key => $value) {
// 	if (is_array($value)) {
// 		$$key = $value;
// 	} else {
// 		$$key = trim(htmlentities(addslashes($value)));
// 	}
// }
// foreach ($_GET as $key => $value) {
// 	if (is_array($value)) {
// 		$$key = $value;
// 	} else {
// 		$$key = trim(htmlentities(addslashes($value)));
// 	}
// }
//echo dirname(dirname(dirname(__FILE__)))."/common/common_functions.php";exit;
/***********************************************************************/


// include_once(dirname(dirname(__FILE__)) . "/common/safestring.php");
// include(dirname(dirname(__FILE__)) . "/common/config.php");
// include(dirname(dirname(__FILE__)) . "/common/conn.php");
// include(dirname(dirname(dirname(__FILE__))) . "/common/common_functions.php");



// include_once(dirname(dirname(__FILE__)) . "/common/encryption.php");
// include_once(dirname(dirname(__FILE__)) . "/common/myemailclass.php");
// include_once(dirname(dirname(__FILE__)) . "/common/admin_messages.php");
// include_once(dirname(dirname(__FILE__)) . "/common/functions.php");


/***********************************************************************/
// $currentFile = $_SERVER["SCRIPT_NAME"];
// $parts = explode('/', $currentFile);
// $currentFile = $parts[count($parts) - 1];

 




// $string = $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"]; 
// $posfind = strpos($string, 'www'); 

// if (strpos($string, 'www') !== false || strpos($string, 'https') !== false) {
// 	//echo 'true';
// } else {
// 	$redirect = str_replace("https", "http", curPageURL()); 
// }

// if (isset($_SERVER["HTTPS"]) || $_SERVER["HTTPS"] == 'on') {
// 	$ssl_url = 'http://' . $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
// 	header('Location:' . $ssl_url);
// 	exit;
// }
