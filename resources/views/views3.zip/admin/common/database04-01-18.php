<?php
	define("ACSQL_DB_USER", "exceed13_music");
	define("ACSQL_DB_PASSWORD", "I,pdwSv;yMT7");
	define("ACSQL_DB_NAME", "exceed13_music_site");
	define("ACSQL_DB_HOST", "localhost");
	
	//	ACSQL Constants
	define("ACSQL_VERSION","1");
	define("OBJECT","OBJECT",true);
	define("ARRAY_A","ARRAY_A",true);
	define("ARRAY_N","ARRAY_N",true);
?>