<script language="javascript" type="text/javascript">
	var js_SERVER_ADMIN_PATH = '<?php echo SERVER_ADMIN_PATH;?>';
	var js_SERVER_ROOTPATH = '<?php echo SERVER_ROOTPATH;?>';
</script>