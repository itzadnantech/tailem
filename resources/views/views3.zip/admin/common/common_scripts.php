<script type="text/javascript" src="<?php echo SERVER_ROOTPATH;?>js/jsconfig.js"></script>
<script type="text/javascript" src="<?php echo SERVER_ROOTPATH;?>js/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="<?php echo SERVER_ROOTPATH;?>js/jquery.form.js"></script>
<script type="text/javascript" src="<?php echo SERVER_ROOTPATH;?>js/ajaxfunctions.js"></script>
