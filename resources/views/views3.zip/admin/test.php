<?php
ob_start();

session_start();

?>
<h1>Welcome here</h1>