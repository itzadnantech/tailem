// var admin_servername = 'http://'+location.hostname+'/admin/';
var admin_servername = 'http://127.0.0.1:8000/admin/';
// var admin_servername = 'http://tailem.com.au/admin/';
var JS_ADMIN_SERVER_PATHROOT = admin_servername;
var JS_PATH_ADMIN = admin_servername+'js/';
var CSS_PATH_ADMIN = admin_servername+'css/';
var IMAGE_PATH_ADMIN = admin_servername+'images/';