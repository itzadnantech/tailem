<html class="Public" id="XenForo"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="description" content="this site Maintenance. Hacked By Conficker">
<meta name="keywords" content="Hacked By Conficker, Conficker, ikhy conficker, planetwork, plaNETWORK TEAM, pnt, Conficker pnt, hacked by Conficker, ikhy, ikhy , exploit, local exploits, tcl, root exploits, index of tcl, linux, tcl eggdrop, Conficker , owned by Conficker, Conficker plaNETWORK, plaNETWORK , conficker, bot, irc">
<meta charset="utf-8">
	<title>./Hacked By Conficker</title>
<link rel="SHORTCUT ICON" href="http://th299.photobucket.com/albums/mm314/Novasan84/Animasi/th_indonesian-flag.gif" type="image">	
<body dir="ltr" alink="#00ff00" background="http://i1114.photobucket.com/albums/k538/dorkedz/tessjpg.gif" bgcolor="#000000" link="#00c000" text="#008000" vlink="#00c000">
</head><body>
<br><center><img src="http://panritacikal.files.wordpress.com/2011/01/bendera-indonesia.jpg">
<div align="center"><br>
<BODY bgColor="black"<font color="white"><span style="font-size:10pt;font-family:Courier New">
<font color="red" size="4">This Site Maintenance<br>
 I`m Sorry Admin .....  Please Patch You`re System !
<br><blink>Owned By Conficker</blink></font>
</span><font color="red">
<pre>
        __                        __                       __    
______ |  | _____    ____   _____/  |___  _  _____________|  | __
\____ \|  | \__  \  /    \_/ __ \   __\ \/ \/ /  _ \_  __ \  |/ /
|  |_> >  |__/ __ \|   |  \  ___/|  |  \     (  <_> )  | \/    < 
|   __/|____(____  /___|  /\___  >__|   \/\_/ \____/|__|  |__|_ \
|__|             \/     \/     \/                              \/
<font color="white">
  __                         
_/  |_  ____ _____    _____  
\   __\/ __ \\__  \  /     \ 
 |  | \  ___/ / __ \|  Y Y  \
 |__|  \___  >____  /__|_|  /
           \/     \/      \/ 
<br><marquee scrollamount6" width="40%"><font color="white" size="3">Thanks to: eNdA | kampret | Calvin | onestree | cRoTz | Dr.Cruzz | plaNETWORK TEAM | magelangcyber | indonesiandefacer | indonesianhacker | pontianakcrew | kubucyber | blackhat team | and you :D</font></marquee><br>
</pre>
</div>
<center> <font face="Courier New">